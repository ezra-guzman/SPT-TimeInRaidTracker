## Updating
If you have installed an older version of this mod, you must delete it before installing this version.

## Installation
Drop into `{SPT directory}/user/mods`

## Usage
Go into `{ SPT directory }/user/mods/plebeianrat-TimeInRaidTracker-1.0.1/` to view time tracker files. The files will be named like `{ profile nickname }-time-tracker.txt`.
Note: if you change your profile nickname, a new file will be generated with the new nickname, and time will not be carried over unless you manually copy the contents of the old file into the new one / add them together.
